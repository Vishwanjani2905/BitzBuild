package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"os/signal"
	"proxy-gateway/config"
	"proxy-gateway/dashboard"
	"proxy-gateway/ratelimit"
	"proxy-gateway/stats"
	"proxy-gateway/waf"
	"strings"
	"syscall"
	"time"
)

func getClientIP(r *http.Request) string {
	ip := r.Header.Get("X-Forwarded-For")
	if ip == "" {
		ip = r.RemoteAddr
		if idx := strings.LastIndex(ip, ":"); idx != -1 {
			ip = ip[:idx]
		}
	}
	return ip
}

func loadAndRegister(path string) *config.Config {
	cfg, err := config.Load(path)
	if err != nil {
		log.Fatalf("Failed to load config: %v", err)
	}
	for _, rl := range cfg.RateLimits {
		ratelimit.RegisterRoute(rl.Method, rl.Path, rl.Limit, rl.WindowSeconds)
	}
	return cfg
}

func main() {
	cfg := loadAndRegister("config.json")

	go func() {
		var lastMod time.Time
		for {
			time.Sleep(5 * time.Second)
			info, err := os.Stat("config.json")
			if err == nil && info.ModTime().After(lastMod) {
				lastMod = info.ModTime()
				loadAndRegister("config.json")
				log.Println("✅ Config reloaded!")
			}
		}
	}()

	backendURL, _ := url.Parse(cfg.Server.BackendURL)
	proxy := httputil.NewSingleHostReverseProxy(backendURL)

	mux := http.NewServeMux()

	// Dashboard
	mux.HandleFunc("/dashboard", dashboard.Handler)

	// ── NEW: JSON stats API for live dashboard ──
	mux.HandleFunc("/api/stats", func(w http.ResponseWriter, r *http.Request) {
		snap := stats.GetSnapshot()

		type FeedItem struct {
			IP     string `json:"ip"`
			Reason string `json:"reason"`
			Time   string `json:"time"`
		}

		type Response struct {
			Total      int64      `json:"total"`
			Blocked    int64      `json:"blocked"`
			Allowed    int64      `json:"allowed"`
			RPS        float64    `json:"rps"`
			SQLCount   int        `json:"sql"`
			XSSCount   int        `json:"xss"`
			RateCount  int        `json:"rate"`
			ShellCount int        `json:"shell"`
			Feed       []FeedItem `json:"feed"`
		}

		feed := []FeedItem{}
		for _, e := range snap.Feed {
			if len(feed) >= 8 {
				break
			}
			feed = append(feed, FeedItem{
				IP:     e.IP,
				Reason: e.Reason,
				Time:   e.Time.Format("15:04:05"),
			})
		}

		resp := Response{
			Total:      snap.Total,
			Blocked:    snap.Blocked,
			Allowed:    snap.Allowed,
			RPS:        snap.RPS,
			SQLCount:   snap.SQLCount,
			XSSCount:   snap.XSSCount,
			RateCount:  snap.RateCount,
			ShellCount: snap.ShellCount,
			Feed:       feed,
		}

		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Access-Control-Allow-Origin", "*")
		json.NewEncoder(w).Encode(resp)
	})

	// All traffic through proxy
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		ip := getClientIP(r)
		currentCfg := config.Get()

		stats.RecordRequest()

		if waf.IsBlacklisted(ip, currentCfg.Security.BlacklistedIPs) {
			stats.RecordBlocked(ip, "Blacklisted IP")
			http.Error(w, "403 Forbidden - Your IP has been blacklisted", http.StatusForbidden)
			return
		}

		wafResult := waf.InspectRequest(r, currentCfg.Security.BlockSQLInjection, currentCfg.Security.BlockXSS)
		if wafResult.Blocked {
			stats.RecordBlocked(ip, wafResult.Type+": "+wafResult.Reason)
			w.Header().Set("X-Blocked-By", "WAF")
			http.Error(w, "403 Forbidden - "+wafResult.Type+" Detected", http.StatusForbidden)
			log.Printf("🚨 WAF BLOCK | IP: %s | Type: %s | Reason: %s", ip, wafResult.Type, wafResult.Reason)
			return
		}

		if allowed, reason := ratelimit.AllowWithDefault(ip, r.Method, r.URL.Path); !allowed {
			stats.RecordBlocked(ip, reason)
			w.Header().Set("Retry-After", "60")
			http.Error(w, "429 Too Many Requests - "+reason, http.StatusTooManyRequests)
			log.Printf("🚫 RATE LIMIT | IP: %s | Path: %s", ip, r.URL.Path)
			return
		}

		log.Printf("✅ ALLOW | IP: %s | %s %s", ip, r.Method, r.URL.Path)
		proxy.ServeHTTP(w, r)
	})

	addr := fmt.Sprintf(":%d", cfg.Server.ListenPort)
	log.Printf("🚀 Proxy running on %s → %s", addr, cfg.Server.BackendURL)
	log.Printf("📊 Dashboard at http://localhost%s/dashboard", addr)

	srv := &http.Server{Addr: addr, Handler: mux}
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		if err := srv.ListenAndServe(); err != nil {
			log.Fatal(err)
		}
	}()
	<-quit
	log.Println("Shutting down...")
}