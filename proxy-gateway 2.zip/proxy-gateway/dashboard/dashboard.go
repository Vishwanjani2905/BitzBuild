package dashboard

import (
  "fmt"
  "net/http"
  "proxy-gateway/stats"
  "time"
)

func Handler(w http.ResponseWriter, r *http.Request) {
  total, blocked, feed := stats.GetStats()
  rps := stats.GetRPS()

  allowed := total - blocked
  blockRate := 0.0
  if total > 0 {
    blockRate = float64(blocked) / float64(total) * 100
  }

  html := fmt.Sprintf(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="refresh" content="2">
  <title>Proxy Shield Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', sans-serif; background: #0a0e1a; color: #e0e6ff; min-height: 100vh; }
    
    .header { 
      background: linear-gradient(135deg, #1a1f35 0%%, #0d1117 100%%);
      padding: 20px 30px;
      border-bottom: 1px solid #30363d;
      display: flex; align-items: center; gap: 15px;
    }
    .header h1 { font-size: 1.5em; color: #58a6ff; }
    .header .subtitle { color: #8b949e; font-size: 0.85em; }
    .shield { font-size: 2em; }
    .status-dot { 
      width: 10px; height: 10px; border-radius: 50%%;
      background: #3fb950; margin-left: auto;
      box-shadow: 0 0 8px #3fb950;
      animation: pulse 2s infinite;
    }
    @keyframes pulse { 0%%,100%% { opacity:1; } 50%% { opacity:0.4; } }

    .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; padding: 20px 30px; }
    
    .card {
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 12px;
      padding: 20px;
      position: relative;
      overflow: hidden;
    }
    .card::before {
      content: '';
      position: absolute; top: 0; left: 0; right: 0; height: 3px;
    }
    .card.blue::before { background: linear-gradient(90deg, #58a6ff, #1f6feb); }
    .card.green::before { background: linear-gradient(90deg, #3fb950, #238636); }
    .card.red::before { background: linear-gradient(90deg, #f85149, #da3633); }
    .card.yellow::before { background: linear-gradient(90deg, #d29922, #bb8009); }
    
    .card .label { font-size: 0.75em; color: #8b949e; text-transform: uppercase; letter-spacing: 1px; }
    .card .value { font-size: 2.2em; font-weight: 700; margin: 8px 0 4px; }
    .card.blue .value { color: #58a6ff; }
    .card.green .value { color: #3fb950; }
    .card.red .value { color: #f85149; }
    .card.yellow .value { color: #d29922; }
    .card .sub { font-size: 0.8em; color: #8b949e; }

    .charts-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; padding: 0 30px 20px; }
    .chart-card { background: #161b22; border: 1px solid #30363d; border-radius: 12px; padding: 20px; }
    .chart-card h3 { color: #8b949e; font-size: 0.85em; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 15px; }

    .feed-section { padding: 0 30px 30px; }
    .feed-card { background: #161b22; border: 1px solid #30363d; border-radius: 12px; padding: 20px; }
    .feed-card h3 { color: #8b949e; font-size: 0.85em; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 15px; }
    
    table { width: 100%%; border-collapse: collapse; }
    th { color: #8b949e; font-size: 0.75em; text-transform: uppercase; padding: 8px 12px; text-align: left; border-bottom: 1px solid #30363d; }
    td { padding: 10px 12px; border-bottom: 1px solid #21262d; font-size: 0.88em; }
    tr:last-child td { border-bottom: none; }
    tr:hover td { background: #1c2128; }
    
    .badge {
      display: inline-block; padding: 2px 8px; border-radius: 20px;
      font-size: 0.75em; font-weight: 600;
    }
    .badge.sql { background: #3d1f1f; color: #f85149; border: 1px solid #5a2020; }
    .badge.xss { background: #2d1f3d; color: #d2a8ff; border: 1px solid #3d2060; }
    .badge.rate { background: #1f2d3d; color: #79c0ff; border: 1px solid #204060; }
    .badge.blacklist { background: #3d2f1f; color: #ffa657; border: 1px solid #5a4020; }

    .ip { font-family: monospace; color: #79c0ff; }
    .time-col { color: #8b949e; font-family: monospace; }
  </style>
</head>
<body>
  <div class="header">
    <span class="shield">🛡️</span>
    <div>
      <h1>Proxy Shield</h1>
      <div class="subtitle">Next-Gen API Gateway &amp; WAF — Live Monitor</div>
    </div>
    <div class="status-dot"></div>
  </div>

  <div class="grid">
    <div class="card blue">
      <div class="label">Total Requests</div>
      <div class="value">%d</div>
      <div class="sub">Since startup</div>
    </div>
    <div class="card green">
      <div class="label">Allowed Through</div>
      <div class="value">%d</div>
      <div class="sub">Forwarded to backend</div>
    </div>
    <div class="card red">
      <div class="label">Threats Blocked</div>
      <div class="value">%d</div>
      <div class="sub">%.1f%% block rate</div>
    </div>
    <div class="card yellow">
      <div class="label">Requests / sec</div>
      <div class="value">%.1f</div>
      <div class="sub">Live throughput</div>
    </div>
  </div>

  <div class="charts-row">
    <div class="chart-card">
      <h3>📊 Traffic Breakdown</h3>
      <canvas id="donut" height="200"></canvas>
    </div>
    <div class="chart-card">
      <h3>🔥 Threat Types Detected</h3>
      <canvas id="bar" height="200"></canvas>
    </div>
  </div>

  <div class="feed-section">
    <div class="feed-card">
      <h3>🚫 Live Threat Feed</h3>
      <table>
        <tr>
          <th>Time</th><th>IP Address</th><th>Threat Type</th><th>Details</th>
        </tr>`,
    total, allowed, blocked, blockRate, rps)

  reasonCounts := map[string]int{
    "SQL Injection": 0, "XSS": 0, "Rate Limit": 0, "Blacklist": 0,
  }

  for _, e := range feed {
    badgeClass := "rate"
    badgeLabel := "Rate Limit"
    detail := e.Reason

    if containsStr(e.Reason, "SQL") {
      badgeClass = "sql"
      badgeLabel = "SQL Injection"
      reasonCounts["SQL Injection"]++
    } else if containsStr(e.Reason, "XSS") {
      badgeClass = "xss"
      badgeLabel = "XSS Attack"
      reasonCounts["XSS"]++
    } else if containsStr(e.Reason, "Blacklist") || containsStr(e.Reason, "blacklist") {
      badgeClass = "blacklist"
      badgeLabel = "Blacklisted"
      reasonCounts["Blacklist"]++
    } else {
      reasonCounts["Rate Limit"]++
    }

    html += fmt.Sprintf(`
        <tr>
          <td class="time-col">%s</td>
          <td class="ip">%s</td>
          <td><span class="badge %s">%s</span></td>
          <td>%s</td>
        </tr>`,
      e.Time.Format(time.TimeOnly), e.IP, badgeClass, badgeLabel, detail)
  }

  if len(feed) == 0 {
    html += `<tr><td colspan="4" style="text-align:center;color:#8b949e;padding:30px">No threats detected yet — system is clean ✅</td></tr>`
  }

  html += fmt.Sprintf(`
      </table>
    </div>
  </div>

  <script>
    // Donut chart
    new Chart(document.getElementById('donut'), {
      type: 'doughnut',
      data: {
        labels: ['Allowed', 'Blocked'],
        datasets: [{ 
          data: [%d, %d],
          backgroundColor: ['#238636', '#da3633'],
          borderColor: ['#2ea043', '#f85149'],
          borderWidth: 2
        }]
      },
      options: { 
        responsive: true,
        plugins: { legend: { labels: { color: '#e0e6ff' } } }
      }
    });

    // Bar chart - threat breakdown
    new Chart(document.getElementById('bar'), {
      type: 'bar',
      data: {
        labels: ['SQL Injection', 'XSS Attack', 'Rate Limit', 'Blacklist'],
        datasets: [{
          label: 'Blocks',
          data: [%d, %d, %d, %d],
          backgroundColor: ['#f8514966', '#d2a8ff66', '#79c0ff66', '#ffa65766'],
          borderColor: ['#f85149', '#d2a8ff', '#79c0ff', '#ffa657'],
          borderWidth: 2,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: '#8b949e' }, grid: { color: '#21262d' } },
          y: { ticks: { color: '#8b949e' }, grid: { color: '#21262d' }, beginAtZero: true }
        }
      }
    });
  </script>
</body>
</html>`,
    allowed, blocked,
    reasonCounts["SQL Injection"], reasonCounts["XSS"],
    reasonCounts["Rate Limit"], reasonCounts["Blacklist"])

  w.Header().Set("Content-Type", "text/html")
  fmt.Fprint(w, html)
}

func containsStr(s, substr string) bool {
  return len(s) >= len(substr) && (s == substr ||
    len(s) > 0 && containsSubstr(s, substr))
}

func containsSubstr(s, sub string) bool {
  for i := 0; i <= len(s)-len(sub); i++ {
    if s[i:i+len(sub)] == sub {
      return true
    }
  }
  return false
}

// We can create different request floods per milisecond: Using different powershell windows
