package config

import (
    "encoding/json"
    "os"
    "sync"
)

type RateLimit struct {
    Path          string `json:"path"`
    Method        string `json:"method"`
    Limit         int    `json:"limit"`
    WindowSeconds int    `json:"window_seconds"`
}

type Security struct {
    BlockSQLInjection bool     `json:"block_sql_injection"`
    BlockXSS          bool     `json:"block_xss"`
    BlacklistedIPs    []string `json:"blacklisted_ips"`
}

type Server struct {
    ListenPort int    `json:"listen_port"`
    BackendURL string `json:"backend_url"`
}

type Config struct {
    Server     Server      `json:"server"`
    RateLimits []RateLimit `json:"rate_limits"`
    Security   Security    `json:"security"`
}

var (
    mu      sync.RWMutex
    current *Config
)

func Load(path string) (*Config, error) {
    data, err := os.ReadFile(path)
    if err != nil {
        return nil, err
    }
    var cfg Config
    if err := json.Unmarshal(data, &cfg); err != nil {
        return nil, err
    }
    mu.Lock()
    current = &cfg
    mu.Unlock()
    return &cfg, nil
}

func Get() *Config {
    mu.RLock()
    defer mu.RUnlock()
    return current
}