package ratelimit

import (
    "sync"
    "time"
)

// Each entry tracks request timestamps for one IP + endpoint
type entry struct {
    mu         sync.Mutex
    timestamps []time.Time
}

type Limiter struct {
    mu      sync.RWMutex
    buckets map[string]*entry // key = "IP:path:method"
    limit   int
    window  time.Duration
}

// Store limiters per route
var limiters = struct {
    sync.RWMutex
    m map[string]*Limiter // key = "METHOD:path"
}{m: make(map[string]*Limiter)}

func RegisterRoute(method, path string, limit int, windowSecs int) {
    key := method + ":" + path
    limiters.Lock()
    limiters.m[key] = &Limiter{
        buckets: make(map[string]*entry),
        limit:   limit,
        window:  time.Duration(windowSecs) * time.Second,
    }
    limiters.Unlock()
}

func Allow(ip, method, path string) bool {
    key := method + ":" + path
    limiters.RLock()
    lim, ok := limiters.m[key]
    limiters.RUnlock()

    if !ok {
        return true // No rule = allow
    }

    bucketKey := ip + ":" + key
    lim.mu.Lock()
    e, exists := lim.buckets[bucketKey]
    if !exists {
        e = &entry{}
        lim.buckets[bucketKey] = e
    }
    lim.mu.Unlock()

    now := time.Now()
    cutoff := now.Add(-lim.window)

    e.mu.Lock()
    defer e.mu.Unlock()

    // Remove timestamps outside the window
    fresh := e.timestamps[:0]
    for _, t := range e.timestamps {
        if t.After(cutoff) {
            fresh = append(fresh, t)
        }
    }
    e.timestamps = fresh

    if len(e.timestamps) >= lim.limit {
        return false // Rate limited!
    }

    e.timestamps = append(e.timestamps, now)
    return true
}

// Default fallback limiter for endpoints with no specific rule
var defaultLimiter = &Limiter{
    buckets: make(map[string]*entry),
    limit:   200,
    window:  60 * time.Second,
}

func AllowWithDefault(ip, method, path string) (bool, string) {
    key := method + ":" + path
    limiters.RLock()
    lim, ok := limiters.m[key]
    limiters.RUnlock()

    if !ok {
        // Use default limiter for unlisted endpoints
        lim = defaultLimiter
    }

    bucketKey := ip + ":" + key
    lim.mu.Lock()
    e, exists := lim.buckets[bucketKey]
    if !exists {
        e = &entry{}
        lim.buckets[bucketKey] = e
    }
    lim.mu.Unlock()

    now := time.Now()
    cutoff := now.Add(-lim.window)

    e.mu.Lock()
    defer e.mu.Unlock()

    fresh := e.timestamps[:0]
    for _, t := range e.timestamps {
        if t.After(cutoff) {
            fresh = append(fresh, t)
        }
    }
    e.timestamps = fresh

    if len(e.timestamps) >= lim.limit {
        return false, "Rate Limit Exceeded on " + path
    }

    e.timestamps = append(e.timestamps, now)
    return true, ""
}