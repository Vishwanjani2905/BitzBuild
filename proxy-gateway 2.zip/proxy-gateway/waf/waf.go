package waf

import (
	"io"
	"net/http"
	"strings"
)

var sqlPatterns = []string{
	"drop table", "or 1=1", "'; --", "union select",
	"insert into", "delete from", "exec(", "xp_cmdshell",
	"' or '", "1=1--", "benchmark(", "sleep(",
	"select * from", "having 1=1", "group by 1",
	"order by 1--", "cast(", "convert(", "char(",
	"information_schema", "sys.tables", "waitfor delay",
}

var xssPatterns = []string{
	"<script", "javascript:", "onerror=", "onload=",
	"alert(", "<iframe", "document.cookie", "eval(",
	"onmouseover=", "onfocus=", "onclick=", "onkeypress=",
	"<img src=", "src=javascript", "expression(",
	"vbscript:", "<object", "<embed", "fromcharcode(",
}

var pathTraversalPatterns = []string{
	"../", "..\\", "%2e%2e%2f", "%2e%2e/",
	"..%2f", "%2e%2e%5c", "....//", "..;/",
}

var shellInjectionPatterns = []string{
	"; ls", "| ls", "&& ls", "; cat /",
	"| cat /", "/etc/passwd", "/etc/shadow",
	"; rm -rf", "| rm -rf", "`whoami`",
	"$(whoami)", "; wget ", "| wget ",
	"; curl ", "| curl ", "nc -e",
}

type WAFResult struct {
	Blocked bool
	Reason  string
	Type    string
}

// readBody reads and restores the request body so it can be read again by the proxy
func readBody(r *http.Request) string {
	if r.Body == nil {
		return ""
	}
	bodyBytes, err := io.ReadAll(io.LimitReader(r.Body, 1024*10)) // max 10KB
	if err != nil {
		return ""
	}
	// Restore body for forwarding to backend
	r.Body = io.NopCloser(strings.NewReader(string(bodyBytes)))
	return string(bodyBytes)
}

func extractFullPayload(r *http.Request) string {
	parts := []string{}

	// 1. Query parameters
	parts = append(parts, r.URL.RawQuery)

	// 2. URL path
	parts = append(parts, r.URL.Path)

	// 3. Request body
	parts = append(parts, readBody(r))

	// 4. Suspicious headers
	parts = append(parts, r.Header.Get("User-Agent"))
	parts = append(parts, r.Header.Get("Referer"))
	parts = append(parts, r.Header.Get("Cookie"))
	parts = append(parts, r.Header.Get("X-Forwarded-For"))

	return strings.ToLower(strings.Join(parts, " "))
}

func InspectRequest(r *http.Request, blockSQL bool, blockXSS bool) WAFResult {
	payload := extractFullPayload(r)

	// 1. SQL Injection
	if blockSQL {
		for _, p := range sqlPatterns {
			if strings.Contains(payload, p) {
				return WAFResult{
					Blocked: true,
					Reason:  "SQL Injection pattern detected: " + p,
					Type:    "SQL Injection",
				}
			}
		}
	}

	// 2. XSS
	if blockXSS {
		for _, p := range xssPatterns {
			if strings.Contains(payload, p) {
				return WAFResult{
					Blocked: true,
					Reason:  "XSS pattern detected: " + p,
					Type:    "XSS Attack",
				}
			}
		}
	}

	// 3. Path Traversal (always on)
	for _, p := range pathTraversalPatterns {
		if strings.Contains(payload, p) {
			return WAFResult{
				Blocked: true,
				Reason:  "Path traversal attempt detected",
				Type:    "Path Traversal",
			}
		}
	}

	// 4. Shell Injection (always on)
	for _, p := range shellInjectionPatterns {
		if strings.Contains(payload, p) {
			return WAFResult{
				Blocked: true,
				Reason:  "Shell injection attempt detected",
				Type:    "Shell Injection",
			}
		}
	}

	return WAFResult{Blocked: false}
}

func IsBlacklisted(ip string, blacklist []string) bool {
	for _, blocked := range blacklist {
		if blocked == ip {
			return true
		}
	}
	return false
}

// Keep old functions so main.go doesn't break
func CheckSQLInjection(r *http.Request) bool {
	payload := strings.ToLower(r.URL.RawQuery + " " + r.URL.Path)
	for _, p := range sqlPatterns {
		if strings.Contains(payload, p) {
			return true
		}
	}
	return false
}

func CheckXSS(r *http.Request) bool {
	payload := strings.ToLower(r.URL.RawQuery + " " + r.URL.Path)
	for _, p := range xssPatterns {
		if strings.Contains(payload, p) {
			return true
		}
	}
	return false
}