const http = require('http');
const url  = require('url');

const users = [
  { id: 1, username: 'alice',   email: 'alice@company.com',   role: 'admin' },
  { id: 2, username: 'bob',     email: 'bob@company.com',     role: 'user'  },
  { id: 3, username: 'charlie', email: 'charlie@company.com', role: 'user'  },
  { id: 4, username: 'diana',   email: 'diana@company.com',   role: 'manager'},
];

function send(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise(resolve => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try { resolve(JSON.parse(body)); }
      catch { resolve(Object.fromEntries(new URLSearchParams(body))); }
    });
  });
}

const server = http.createServer(async (req, res) => {
  const parsed  = url.parse(req.url, true);
  const path    = parsed.pathname;
  const method  = req.method;

  console.log(`[BACKEND] ${method} ${path}`);

  // ── GET /getAllUsers ──
  if (path === '/getAllUsers' && method === 'GET') {
    return send(res, 200, { success: true, count: users.length, users });
  }

  // ── POST /login ──
  if (path === '/login' && method === 'POST') {
    const body = await readBody(req);
    const user = users.find(u => u.username === body.username);
    if (user && body.password === 'password123') {
      return send(res, 200, {
        success: true,
        token: 'jwt_token_' + user.id + '_' + Date.now(),
        user: { id: user.id, username: user.username, role: user.role }
      });
    }
    return send(res, 401, { success: false, message: 'Invalid credentials' });
  }

  // ── GET /user/:id ──
  if (path.startsWith('/user/') && method === 'GET') {
    const id   = parseInt(path.split('/')[2]);
    const user = users.find(u => u.id === id);
    if (user) return send(res, 200, { success: true, user });
    return send(res, 404, { success: false, message: 'User not found' });
  }

  // ── GET /health ──
  if (path === '/health') {
    return send(res, 200, {
      status: 'healthy',
      uptime: process.uptime().toFixed(0) + 's',
      timestamp: new Date().toISOString()
    });
  }

  // ── 404 ──
  send(res, 404, { success: false, message: 'Endpoint not found' });
});

server.listen(8080, () => {
  console.log('✅ Backend running on http://localhost:8080');
  console.log('   GET  /getAllUsers');
  console.log('   POST /login');
  console.log('   GET  /user/:id');
  console.log('   GET  /health');
});