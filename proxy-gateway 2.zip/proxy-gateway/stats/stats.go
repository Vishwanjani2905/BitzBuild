package stats

import (
	"sync"
	"time"
)

type BlockedEvent struct {
	IP     string
	Reason string
	Time   time.Time
}

type Snapshot struct {
	Total      int64
	Blocked    int64
	Allowed    int64
	RPS        float64
	Feed       []BlockedEvent
	SQLCount   int
	XSSCount   int
	RateCount  int
	ShellCount int
}

var (
	mu           sync.RWMutex
	totalReqs    int64
	blockedReqs  int64
	blockedFeed  []BlockedEvent
	reqTimestamp []time.Time
)

func RecordRequest() {
	mu.Lock()
	totalReqs++
	reqTimestamp = append(reqTimestamp, time.Now())
	mu.Unlock()
}

func RecordBlocked(ip, reason string) {
	mu.Lock()
	blockedReqs++
	blockedFeed = append([]BlockedEvent{{IP: ip, Reason: reason, Time: time.Now()}}, blockedFeed...)
	if len(blockedFeed) > 100 {
		blockedFeed = blockedFeed[:100]
	}
	mu.Unlock()
}

func GetRPS() float64 {
	mu.Lock()
	defer mu.Unlock()

	now := time.Now()
	window := 5 * time.Second
	cutoff := now.Add(-window)

	fresh := reqTimestamp[:0]
	for _, t := range reqTimestamp {
		if t.After(now.Add(-30 * time.Second)) {
			fresh = append(fresh, t)
		}
	}
	reqTimestamp = fresh

	count := 0
	for _, t := range reqTimestamp {
		if t.After(cutoff) {
			count++
		}
	}

	// Average over 5 second window
	return float64(count) / 5.0
}

func GetStats() (int64, int64, []BlockedEvent) {
	mu.RLock()
	defer mu.RUnlock()
	return totalReqs, blockedReqs, blockedFeed
}

func GetSnapshot() Snapshot {
	mu.Lock()
	defer mu.Unlock()

	now := time.Now()
	cutoff := now.Add(-time.Second)
	count := 0
	fresh := reqTimestamp[:0]
	for _, t := range reqTimestamp {
		if t.After(now.Add(-10 * time.Second)) {
			fresh = append(fresh, t)
		}
	}
	reqTimestamp = fresh
	for _, t := range reqTimestamp {
		if t.After(cutoff) {
			count++
		}
	}

	sqlC, xssC, rateC, shellC := 0, 0, 0, 0
	for _, e := range blockedFeed {
		r := e.Reason
		switch {
		case contains(r, "SQL"):
			sqlC++
		case contains(r, "XSS"):
			xssC++
		case contains(r, "Shell"):
			shellC++
		default:
			rateC++
		}
	}

	feedCopy := make([]BlockedEvent, len(blockedFeed))
	copy(feedCopy, blockedFeed)

	return Snapshot{
		Total:      totalReqs,
		Blocked:    blockedReqs,
		Allowed:    totalReqs - blockedReqs,
		RPS:        float64(count),
		Feed:       feedCopy,
		SQLCount:   sqlC,
		XSSCount:   xssC,
		RateCount:  rateC,
		ShellCount: shellC,
	}
}

func contains(s, sub string) bool {
	if len(sub) > len(s) {
		return false
	}
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}